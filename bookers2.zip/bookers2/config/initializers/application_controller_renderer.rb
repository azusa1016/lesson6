# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'd383f148c277b94ee8a57e5c67f2d3eb2accb47e63d5cb2cc1f86e3ca4a6400d6ad5ee1c8e5735d5ed3e006dbb8dafa37ed6ff36e68c8394bfbf827d6e5aa822'